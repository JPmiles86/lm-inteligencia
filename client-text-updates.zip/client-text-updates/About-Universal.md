# About Page - Universal Content (All Verticals)
**Instructions:** This content appears the same across ALL industry verticals. Replace the "Current" text with your "New" text. Leave blank if no changes needed.

---

## PAGE HERO SECTION

### Hero Title
**Current:** About Inteligencia

**New:** 

### Hero Subtitle/Description
**Current:** At Inteligencia, we blend AI and Data strategy with human insight to deliver digital marketing that performs. We're not another churn-and-burn agency - we specialize in building lean, high-impact campaigns that turn ad dollars into measurable growth. We bring the data, creative, and performance muscle to get you there. Our founder, Laurie Meiring, brings 10 years of hospitality and digital marketing leadership - we know how to grow businesses from the inside out. Smart strategy. Bold execution. Real results. That's Inteligencia.

**New:** 

---

## FOUNDER SECTION

### Founder Headshot Image
**Current:** /images/laurie-meiring-headshot.jpg

**New:** 
(Upload headshot image file or provide URL)

### Section Title
**Current:** Meet Laurie Meiring

**New:** 

### Founder Title
**Current:** Founder & Chief Strategist

**New:** 

### Tagline
**Current:** MBA • Agile Marketing Leader • AI‑Driven Digital Innovator • Hospitality Veteran

**New:** 

### Short Bio
**Current:** Laurie Meiring brings over 10 years of hands-on digital marketing leadership to Inteligencia, backed by an MBA and a career that bridges the worlds of hospitality, AI-driven performance marketing, and creative brand building.

**New:** 

### Extended Story
**Current:** Before founding Inteligencia, Laurie served as Director of Digital Marketing at Web Marketing for Dentists, where he led a team managing over $750K/month in Google Ads and $80K+/month in Meta spend for 200+ dental practices across North America. His results-first approach helped local businesses consistently outperform national competitors.

**New:** 

### Approach/Philosophy
**Current:** He launched Inteligencia with a clear belief: different industries require deeply tailored marketing - not cookie-cutter solutions. That's why the agency focuses on four core verticals where Laurie has developed meaningful expertise: hospitality, tech, healthcare, and sports/media. Laurie's campaigns are equal parts data science and storytelling - designed to drive ROI while resonating with real human needs. He blends strategic insight with deep client empathy, helping businesses grow through performance marketing that actually performs.

**New:** 

---

## QUALIFICATIONS SECTION

### Section Title
**Current:** Degrees and Qualifications

**New:** 

### Qualification 1
**Current:** MBA – Digital Marketing, Cum Laude (2018)

**New:** 

### Qualification 2
**Current:** Bachelor's in Hotel and Restaurant Management (2003)

**New:** 

### Qualification 3
**Current:** Chef's Diploma (2012)

**New:** 

### Qualification 4
**Current:** Advanced Digital Marketing Certificate (2023)

**New:** 

### Qualification 5
**Current:** Ship 30 for 30 Digital Writing Course (2023)

**New:** 

---

## VALUES SECTION

### Section Title
**Current:** Our Values

**New:** 

### Section Subtitle
**Current:** These core principles reflect how we think, how we work, and how we show up for our clients—every single time.

**New:** 

### Value 1: Title
**Current:** Hospitality Work Ethic

**New:** 

### Value 1: Description
**Current:** Relentless reliability, responsiveness, and attention to detail. Our roots in hospitality mean we show up with integrity, hustle, and a client-first mindset - always.

**New:** 

### Value 2: Title
**Current:** AI-Driven Innovation

**New:** 

### Value 2: Description
**Current:** We embrace AI as a force multiplier, not a shortcut. From advanced targeting to content generation, we leverage cutting-edge tools to stay ahead of the curve—and so do our clients.

**New:** 

### Value 3: Title
**Current:** Results Obsessed

**New:** 

### Value 3: Description
**Current:** We don't chase vanity metrics. We build and optimize campaigns around what actually matters - profitability, growth, and long-term value.

**New:** 

### Value 4: Title
**Current:** Creative Firepower

**New:** 

### Value 4: Description
**Current:** Creative isn't just how things look—it's how strategies come to life. From storytelling to campaign structure, we combine artistic instinct with marketing science to produce standout work.

**New:** 

### Value 5: Title
**Current:** Industry Expertise

**New:** 

### Value 5: Description
**Current:** Deep specialization in hospitality, healthcare, tech and sports/media marketing.

**New:** 

### Value 6: Title
**Current:** Data-Driven Results

**New:** 

### Value 6: Description
**Current:** Every campaign is measured, optimized, and designed to deliver measurable ROI.

**New:** 

### Value 7: Title
**Current:** Ethical Practices

**New:** 

### Value 7: Description
**Current:** HIPAA compliance, transparent reporting, and honest communication in all client relationships.

**New:** 

### Value 8: Title
**Current:** Long-term Partnership

**New:** 

### Value 8: Description
**Current:** We build lasting relationships focused on sustainable business growth and success.

**New:** 

---

## TEAM SECTION

### Section Title
**Current:** Our Expert Team

**New:** 

### Section Subtitle
**Current:** Industry specialists with proven track records of delivering exceptional results across hospitality, healthcare, tech, and sports/media businesses.

**New:** 

---

## BOTTOM CTA SECTION

### CTA Title
**Current:** Ready to Work Together?

**New:** 

### CTA Subtitle
**Current:** Let's discuss how our specialized expertise can help grow your business with industry-specific marketing solutions.

**New:** 

### Primary CTA Button Text
**Current:** Get Started Today

**New:** 

### Secondary CTA Button Text
**Current:** View Our Services

**New:** 

---

## NOTES
- This content appears on the About page for ALL industry verticals
- Team member profiles are configured separately per industry
- Images and media are handled separately
- Navigation and footer content are universal across all pages
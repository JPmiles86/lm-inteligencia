# Universal Pricing Structure - All Verticals
**Note:** These pricing elements are typically the same across ALL industry verticals. Only update if changing globally.

---

## PRICING TIERS (Same for all verticals)

### Tier 1 - Starter
**Price:** $1,500/month
**Ad Spend Limit:** Up to $5K/month
**Channels:** 1 Paid Channel
**Campaigns:** 2 Campaigns per month
**Strategy Calls:** 2 x 30-min calls/month

### Tier 2 - Growth (RECOMMENDED)
**Price:** $3,000/month
**Ad Spend Limit:** Up to $20K/month
**Channels:** 2 Paid Channels
**Campaigns:** 4 Campaigns per month
**Strategy Calls:** Bi-weekly 60 min calls

### Tier 3 - Pro+
**Price:** $5,500/month+
**Ad Spend Limit:** Up to $75K/month
**Channels:** Up to 3 Paid Channels
**Strategy Calls:** Weekly calls

---

## UNIVERSAL FEATURES (Included in plans across all verticals)

### Starter Features (Universal)
- Monthly Reporting Dashboard
- Basic Conversion Tracking Setup
- Email Support

### Growth Features (Universal)
- Custom Reporting Dashboard
- Landing Page UX Consultation (1/month)
- Advanced Tracking Setup
- Priority Email Support

### Pro+ Features (Universal)
- Dedicated Account Manager
- Priority Support & Chat Access
- Weekly Performance Calls
- Advanced Tracking Setup (GA4, GTM, Pixels)

---

## ADD-ON PRICING (Same across all verticals)

**Landing Page Build:** $300
**Email Funnel Setup:** $950
**Ad Creative Design:** $250/ad set
**Marketing Audit + Strategy (90 min):** $399

---

## WHAT CHANGES PER VERTICAL?

The following elements SHOULD be customized per industry in the individual vertical files:

1. **Plan Names** - Include industry name (e.g., "Starter Hospitality" vs "Starter Healthcare")
2. **Plan Descriptions** - Industry-specific value propositions
3. **"Perfect For" Text** - Target audience per industry
4. **Industry-Specific Features** - Unique offerings per vertical
5. **Service Descriptions** - Tailored to industry needs

---

## NOTES
- If changing prices, update across ALL verticals
- Consider market positioning before adjusting
- Add-on prices should remain consistent for simplicity
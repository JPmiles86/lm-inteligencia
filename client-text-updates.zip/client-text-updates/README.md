# Client Text Update Files

This folder contains structured text comparison files to help Laurie update website content across different industry verticals.

## How to Use These Files

1. **Open the relevant file** for the page and industry you want to update
2. **Review each "Current" text** - this is what's currently on the website
3. **Enter your new text** in the "New:" field for any text you want to change
4. **Leave "New:" blank** if you want to keep the current text
5. **Save the file** and provide it back for implementation

## File Structure

```
client-text-updates/
├── README.md (this file)
├── About-Universal.md (same for all industries)
├── Pricing-Universal-Structure.md (pricing that's same across verticals)
├── hospitality/
│   ├── Home-Hospitality.md
│   ├── Services-Hospitality.md
│   ├── CaseStudies-Hospitality.md
│   └── Contact-Hospitality.md
├── healthcare/
│   ├── Home-Healthcare.md
│   ├── Services-Healthcare.md
│   ├── CaseStudies-Healthcare.md
│   └── Contact-Healthcare.md
├── tech/
│   ├── Home-Tech.md
│   ├── Services-Tech.md
│   ├── CaseStudies-Tech.md
│   └── Contact-Tech.md
├── athletics/
│   ├── Home-Athletics.md
│   ├── Services-Athletics.md
│   ├── CaseStudies-Athletics.md
│   └── Contact-Athletics.md
└── blog/
    ├── BlogListing-Universal.md (main blog page)
    ├── BlogPost-Template.md (template for new posts)
    ├── BlogPost-1-OTA-Commissions.md
    ├── BlogPost-2-Restaurant-Social-Media.md
    ├── BlogPost-3-HIPAA-Compliant-Marketing.md
    ├── BlogPost-4-Sports-Facility-Marketing.md
    ├── BlogPost-5-Digital-Marketing-Trends-2025.md
    ├── BlogPost-6-Local-SEO-Mastery.md
    ├── BlogPost-7-Email-Marketing-Automation.md
    ├── BlogPost-8-Google-Ads-Guide.md
    ├── BlogPost-9-SaaS-Growth-Marketing.md
    ├── BlogPost-10-AI-Product-Marketing.md
    └── BlogPost-11-B2B-Demand-Generation.md
```

## File Naming Convention

- **Page-Industry.md** format for industry-specific content
- **Page-Universal.md** for content that's the same across all industries

## What's Included

Each file contains:
- **Text content** - all visible text on the page
- **Media placeholders** - locations for images and videos
- **Clear formatting** - "Current" text with space for "New" text below

## Important Notes

### For Laurie:
- You can edit these files in Google Docs - just upload the MD file
- **Text Updates**: Fill in the "New:" fields only where you want changes
- **Media Updates**: Provide new image files or URLs where indicated
- **Gradients/Colors**: Background gradients (like Contact page) are handled in code, not images
- Some text appears in multiple places (like testimonials on Home and Case Studies pages)
- Navigation menu items are universal across all pages

### Media Guidelines:
- **Images**: Provide as PNG, JPG, or WebP files (or URLs)
- **Videos**: Provide Vimeo or YouTube URLs (or upload MP4 files)
- Leave media fields blank if keeping current ones

### Text Formatting Tips:
- Keep formatting simple (no need for bold/italic unless specifically needed)
- Line breaks matter - use them to separate paragraphs
- Don't worry about links - they're handled in the code
- Numbers and percentages should be exact (e.g., "40%" not "forty percent")

## Industry Verticals

All verticals are now created:
- ✅ **Hospitality** - Hotels, resorts, restaurants
- ✅ **Healthcare** - Dental, medical, wellness practices  
- ✅ **Tech** - SaaS, AI companies, tech startups
- ✅ **Athletics** - Sports facilities, pickleball, tournaments

## Example Entry

```markdown
### Hero Title
**Current:** Digital Marketing That Drives Occupancy & Grows RevPAR
**New:** Your Hotel's Growth Partner for Direct Bookings
```

In this example, the hero title would change from the current text to the new text.

## Questions?

If you need files for other verticals or pages, just ask and they can be created following the same format.
# Athletics Home Page - Text Updates
**Instructions:** Replace the "Current" text with your "New" text. Leave blank if no changes needed.

---

## HERO SECTION

### Hero Background Video (Desktop)
**Current:** https://player.vimeo.com/video/1100417251

**New:** 
(Provide Vimeo or YouTube URL, or upload video file)


### Hero Background Video (Mobile)
**Current:** https://player.vimeo.com/video/1100417904

**New:** 
(Provide Vimeo or YouTube URL, or upload video file)


### Hero Title
**Current:** Fill Your Courts, Grow Your Community

**New:** 


### Hero Subtitle  
**Current:** Drive membership growth and tournament participation with sports marketing expertise

**New:** 


### Hero CTA Button Text
**Current:** Get Free Facility Growth Plan

**New:** 


### Hero Stats (3 metrics displayed)
#### Stat 1 - Value
**Current:** 200%

**New:** 


#### Stat 1 - Label
**Current:** Tournament Participation Growth

**New:** 


#### Stat 2 - Value
**Current:** 85%

**New:** 


#### Stat 2 - Label
**Current:** Facility Utilization Rate

**New:** 


#### Stat 3 - Value
**Current:** 300+

**New:** 


#### Stat 3 - Label
**Current:** New Members This Year

**New:** 


---

## SERVICES SECTION

### Section Title
**Current:** Marketing That Fills Your Facilities

**New:** 


### Section Subtitle
**Current:** Strategic Sports Marketing That Drives Community Growth

**New:** 


---

## SERVICE 1: Sports Facility Marketing

### Service Image
**Current:** /images/SportsFacilityMarketing.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Sports Facility Marketing

**New:** 


### Key Benefit (displayed prominently)
**Current:** Average 85% facility utilization

**New:** 


### Service Description
**Current:** Fill courts, fields, and facilities with targeted campaigns that attract active participants.

**New:** 


---

## SERVICE 2: Tournament & Event Promotion

### Service Image
**Current:** /images/TournamentPromotion.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Tournament & Event Promotion

**New:** 


### Key Benefit (displayed prominently)
**Current:** Average 200% increase in participation

**New:** 


### Service Description
**Current:** Fill every tournament bracket and maximize event attendance with targeted marketing.

**New:** 


---

## SERVICE 3: Media & Content Distribution

### Service Image
**Current:** /images/MediaDistribution.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Media & Content Distribution

**New:** 


### Key Benefit (displayed prominently)
**Current:** 5x increase in media reach

**New:** 


### Service Description
**Current:** Amplify your sports brand with professional content creation and multi-channel distribution.

**New:** 


---

## SERVICE 4: Sponsorship & Partnership

### Service Image
**Current:** /images/SponsorshipMarketing.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Sponsorship & Partnership

**New:** 


### Key Benefit (displayed prominently)
**Current:** 40% increase in sponsorship revenue

**New:** 


### Service Description
**Current:** Attract and retain valuable sponsors with data-driven partnership marketing strategies.

**New:** 


---

## SERVICE 5: Pickleball & Niche Sports

### Service Image
**Current:** /images/NicheSports.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Pickleball & Niche Sports

**New:** 


### Key Benefit (displayed prominently)
**Current:** Build 1,000+ member communities

**New:** 


### Service Description
**Current:** Specialized marketing for emerging sports communities and niche athletic activities.

**New:** 


---

## SERVICE 6: Digital Ticketing & Sales

### Service Image
**Current:** /images/DigitalTicketing.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Digital Ticketing & Sales

**New:** 


### Key Benefit (displayed prominently)
**Current:** 60% increase in advance sales

**New:** 


### Service Description
**Current:** Maximize ticket sales and event revenue with integrated digital sales platforms.

**New:** 


---

## SERVICE 7: Brand & Athlete Marketing

### Service Image
**Current:** /images/AthleteMarketing.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Brand & Athlete Marketing

**New:** 


### Key Benefit (displayed prominently)
**Current:** 10x social media growth

**New:** 


### Service Description
**Current:** Build powerful personal brands for athletes and sports organizations.

**New:** 


---

## TESTIMONIALS SECTION

### TESTIMONIAL 1: Championship Sports Complex

#### Quote
**Current:** Since partnering with Inteligencia, our tournament participation has doubled and we've added 300 new members. Laurie understands the sports community like no other marketer we've worked with.

**New:** 


#### Author Name
**Current:** Mike Thompson

**New:** 


#### Author Position
**Current:** Facility Director

**New:** 


#### Company Name
**Current:** Championship Sports Complex

**New:** 


#### Location
**Current:** Central Coast, CA

**New:** 


---

### TESTIMONIAL 2: Elite Sports Center

#### Quote
**Current:** Our facility utilization improved from 60% to 85% after implementing Laurie's membership growth strategies. The community engagement programs have been a game-changer.

**New:** 


#### Author Name
**Current:** Lisa Park

**New:** 


#### Author Position
**Current:** Operations Manager

**New:** 


#### Company Name
**Current:** Elite Sports Center

**New:** 


#### Location
**Current:** Phoenix, AZ

**New:** 


---

### TESTIMONIAL 3: Coastal Recreation Complex

#### Quote
**Current:** The tournament promotion strategies Laurie developed helped us host our largest event ever with 500+ participants. The community response was overwhelming.

**New:** 


#### Author Name
**Current:** James Rodriguez

**New:** 


#### Author Position
**Current:** Event Coordinator

**New:** 


#### Company Name
**Current:** Coastal Recreation Complex

**New:** 


#### Location
**Current:** San Diego, CA

**New:** 


---

## VIDEO CTA SECTION (Bottom of page)

### Headline
**Current:** Ready to build your sports community?

**New:** 


### Subtitle
**Current:** Let's discuss how targeted marketing can help you maximize facility utilization and tournament participation

**New:** 


### CTA Button Text
**Current:** Get Your Free Facility Analysis

**New:** 


### Trust Indicators (3 lines displayed)
#### Line 1
**Current:** Free Facility Growth Plan

**New:** 


#### Line 2
**Current:** Community Building Expertise

**New:** 


#### Line 3
**Current:** Results in 60 Days

**New:** 


---

## NOTES
- Images are handled separately and don't need text updates
- Video backgrounds are configured separately
- Some text may appear differently based on screen size
- Navigation menu items are universal across all pages
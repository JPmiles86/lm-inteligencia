# Healthcare Contact Page - Text Updates
**Instructions:** Replace the "Current" text with your "New" text. Leave blank if no changes needed.

---

## PAGE HERO SECTION
*Note: Background uses a gradient effect (black → blue → black), not an image*

### Hero Title
**Current:** Ready to Grow Your Healthcare Practice?

**New:** 

### Hero Subtitle
**Current:** Get your free practice growth plan and discover how to attract quality patients with HIPAA-compliant marketing strategies.

**New:** 

---

## CONTACT FORM SECTION

### Form Title
**Current:** Send us a message

**New:** 

### Form Subtitle
**Current:** Fill out the form below and we'll get back to you within 24 hours with a customized strategy for your practice.

**New:** 

### Form Fields Labels
#### First Name Label
**Current:** First Name *

**New:** 

#### Last Name Label
**Current:** Last Name *

**New:** 

#### Email Label
**Current:** Email Address *

**New:** 

#### Phone Label
**Current:** Phone Number

**New:** 

#### Business Name Label
**Current:** Practice Name *

**New:** 

#### Business Type Label
**Current:** Practice Type *

**New:** 

### Business Type Options (Dropdown)
#### Option 1
**Current:** Select your practice type

**New:** 

#### Option 2
**Current:** General Dentistry

**New:** 

#### Option 3
**Current:** Dental Specialty

**New:** 

#### Option 4
**Current:** Medical Practice

**New:** 

#### Option 5
**Current:** Wellness Center

**New:** 

#### Option 6
**Current:** Fitness Facility

**New:** 

#### Option 7
**Current:** Health Spa/Retreat

**New:** 

#### Option 8
**Current:** Urgent Care

**New:** 

#### Option 9
**Current:** Healthcare Group

**New:** 

#### Option 10
**Current:** Other

**New:** 

### Marketing Budget Label
**Current:** Marketing Budget

**New:** 

### Budget Options (Dropdown)
#### Option 1
**Current:** Select your budget range

**New:** 

#### Option 2
**Current:** $1,000 - $2,500/month

**New:** 

#### Option 3
**Current:** $2,500 - $5,000/month

**New:** 

#### Option 4
**Current:** $5,000 - $10,000/month

**New:** 

#### Option 5
**Current:** $10,000+ /month

**New:** 

#### Option 6
**Current:** Let's discuss

**New:** 

### Timeline Label
**Current:** Timeline

**New:** 

### Timeline Helper Text
**Current:** When do you want to start?

**New:** 

### Timeline Options (Dropdown)
#### Option 1
**Current:** ASAP - I need help now

**New:** 

#### Option 2
**Current:** Within 1 month

**New:** 

#### Option 3
**Current:** 1-3 months

**New:** 

#### Option 4
**Current:** 3-6 months

**New:** 

#### Option 5
**Current:** Just exploring options

**New:** 

### Goals Field Label
**Current:** What are your main practice goals? *

**New:** 

### Additional Details Label
**Current:** Additional Details

**New:** 

### Submit Button Text
**Current:** Send Message & Get Free Practice Analysis

**New:** 

### Privacy Text
**Current:** We respect your privacy and will never share your information.

**New:** 

---

## GET IN TOUCH SECTION

### Section Title
**Current:** Get in Touch

**New:** 

### Section Subtitle
**Current:** Ready to discuss your healthcare practice marketing goals? Choose the contact method that works best for you.

**New:** 

### Email Contact
#### Label
**Current:** Email

**New:** 

#### Value
**Current:** health@inteligencia.com

**New:** 

#### Description
**Current:** Email us anytime - we respond within 24 hours

**New:** 

### Phone Contact
#### Label
**Current:** Phone

**New:** 

#### Value
**Current:** (555) 123-4567

**New:** 

#### Description
**Current:** Call us during business hours (9 AM - 6 PM EST)

**New:** 

### Office Contact
#### Label
**Current:** Office

**New:** 

#### Value
**Current:** 123 Business Ave, Suite 100, Miami, FL 33101

**New:** 

#### Description
**Current:** Visit our office for an in-person consultation

**New:** 

---

## SCHEDULE CONSULTATION SECTION

### Section Title
**Current:** Schedule Your Free Healthcare Marketing Consultation

**New:** 

### Section Description
**Current:** Book a 30-minute strategy session to discuss your practice goals and learn how we can help attract quality patients.

**New:** 

### Schedule Button Text
**Current:** Schedule Free Call

**New:** 

---

## OFFICE HOURS SECTION

### Section Title
**Current:** Office Hours

**New:** 

### Monday-Friday Hours
**Current:** Monday - Friday: 9:00 AM - 6:00 PM EST

**New:** 

### Saturday Hours
**Current:** Saturday: 10:00 AM - 2:00 PM EST

**New:** 

### Sunday Hours
**Current:** Sunday: Closed

**New:** 

### Emergency Support Text
**Current:** Emergency support available 24/7 for existing clients.

**New:** 

---

## FAQ SECTION

### Section Title
**Current:** Frequently Asked Questions

**New:** 

### Section Subtitle
**Current:** Common questions about working with our healthcare marketing team.

**New:** 

### FAQ 1
#### Question
**Current:** How quickly can I expect to see results?

**New:** 

#### Answer
**Current:** Most healthcare practices see initial improvements within 30-60 days, with significant patient acquisition typically achieved within 3-6 months. The timeline depends on your current marketing foundation and campaign objectives.

**New:** 

### FAQ 2
#### Question
**Current:** Do you work with practices outside of these industries?

**New:** 

#### Answer
**Current:** We focus exclusively on hospitality, food service, healthcare, and athletics to provide the deepest expertise possible. This specialization allows us to deliver superior results compared to generalist agencies.

**New:** 

### FAQ 3
#### Question
**Current:** Is your marketing HIPAA-compliant?

**New:** 

#### Answer
**Current:** Yes, all our healthcare marketing campaigns are fully HIPAA-compliant. We understand the unique privacy requirements of medical practices and ensure all patient information is protected according to federal regulations.

**New:** 

### FAQ 4
#### Question
**Current:** Do you require long-term contracts?

**New:** 

#### Answer
**Current:** We offer both monthly and annual plans. While we recommend longer commitments for best results, we understand every practice has different needs and can work with you to find the right arrangement.

**New:** 

---

## NOTES
- Icons/emojis are handled separately in code
- Form validation is automatic
- Calendar/scheduling widget is integrated separately
- Some fields may be required or optional based on configuration
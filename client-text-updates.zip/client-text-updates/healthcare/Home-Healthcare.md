# Healthcare Home Page - Text Updates
**Instructions:** Replace the "Current" text with your "New" text. Leave blank if no changes needed.

---

## HERO SECTION

### Hero Background Video (Desktop)
**Current:** https://player.vimeo.com/video/1100417251

**New:** 
(Provide Vimeo or YouTube URL, or upload video file)


### Hero Background Video (Mobile)
**Current:** https://player.vimeo.com/video/1100417904

**New:** 
(Provide Vimeo or YouTube URL, or upload video file)


### Hero Title
**Current:** Grow Your Practice with HIPAA-Compliant Marketing

**New:** 


### Hero Subtitle  
**Current:** Attract quality patients and build trust with ethical marketing strategies designed for healthcare

**New:** 


### Hero CTA Button Text
**Current:** Get Free Practice Growth Plan

**New:** 


### Hero Stats (3 metrics displayed)
#### Stat 1 - Value
**Current:** 120+

**New:** 


#### Stat 1 - Label
**Current:** New Patients Monthly

**New:** 


#### Stat 2 - Value
**Current:** 4.8+

**New:** 


#### Stat 2 - Label
**Current:** Star Reputation Average

**New:** 


#### Stat 3 - Value
**Current:** 40%

**New:** 


#### Stat 3 - Label
**Current:** Higher Patient Lifetime Value

**New:** 


---

## SERVICES SECTION

### Section Title
**Current:** Marketing That Attracts Quality Patients

**New:** 


### Section Subtitle
**Current:** HIPAA-Compliant Strategies for Healthcare Providers

**New:** 


---

## SERVICE 1: Patient Acquisition Campaigns

### Service Image
**Current:** /images/PatientAcquisition.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Patient Acquisition Campaigns

**New:** 


### Key Benefit (displayed prominently)
**Current:** 150+ new patients monthly

**New:** 


### Service Description
**Current:** Attract quality patients with targeted campaigns that reach people actively seeking healthcare services.

**New:** 


---

## SERVICE 2: Reputation Management

### Service Image
**Current:** /images/ReputationManagement.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Healthcare Reputation Management

**New:** 


### Key Benefit (displayed prominently)
**Current:** Achieve 4.8+ star average rating

**New:** 


### Service Description
**Current:** Build trust and credibility with a 5-star online reputation across all review platforms.

**New:** 


---

## SERVICE 3: Content Marketing

### Service Image
**Current:** /images/HealthcareContent.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Healthcare Content Marketing

**New:** 


### Key Benefit (displayed prominently)
**Current:** 500% traffic growth

**New:** 


### Service Description
**Current:** Educate and engage patients with valuable health content that positions you as the trusted expert.

**New:** 


---

## SERVICE 4: Telehealth Marketing

### Service Image
**Current:** /images/TelehealthMarketing.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Telehealth & Digital Solutions

**New:** 


### Key Benefit (displayed prominently)
**Current:** 200% virtual visit growth

**New:** 


### Service Description
**Current:** Expand your reach with virtual care marketing and digital patient engagement strategies.

**New:** 


---

## TESTIMONIALS SECTION

### TESTIMONIAL 1: Mountain Wellness Retreat

#### Quote
**Current:** Inteligencia understood our mission of transformational wellness and helped us reach people genuinely seeking life change. Our retreats are now consistently full with passionate participants.

**New:** 


#### Author Name
**Current:** Dr. Amanda Foster

**New:** 


#### Author Position
**Current:** Founder & Wellness Director

**New:** 


#### Company Name
**Current:** Mountain Wellness Retreat

**New:** 


#### Location
**Current:** Colorado, USA

**New:** 


---

### TESTIMONIAL 2: Elite Fitness Studio

#### Quote
**Current:** They helped us build a true fitness community, not just a gym. Our members are now our biggest advocates, and we have waitlists for most of our classes.

**New:** 


#### Author Name
**Current:** Marcus Thompson

**New:** 


#### Author Position
**Current:** Owner & Head Trainer

**New:** 


#### Company Name
**Current:** Elite Fitness Studio

**New:** 


#### Location
**Current:** Austin, Texas

**New:** 


---

### TESTIMONIAL 3: Mind Body Clinic

#### Quote
**Current:** They understood both our HIPAA requirements and our holistic approach. Now we're helping more people than ever achieve true mind-body wellness.

**New:** 


#### Author Name
**Current:** Dr. Jennifer Chen

**New:** 


#### Author Position
**Current:** Practice Owner

**New:** 


#### Company Name
**Current:** Mind Body Clinic

**New:** 


#### Location
**Current:** San Francisco, CA

**New:** 


---

## VIDEO CTA SECTION (Bottom of page)

### Headline
**Current:** Ready to grow your healthcare practice?

**New:** 


### Subtitle
**Current:** Let's discuss how ethical, HIPAA-compliant marketing can help you attract quality patients

**New:** 


### CTA Button Text
**Current:** Get Your Free Practice Analysis

**New:** 


### Trust Indicators (3 lines displayed)
#### Line 1
**Current:** Free Practice Growth Plan

**New:** 


#### Line 2
**Current:** HIPAA-Compliant Strategies

**New:** 


#### Line 3
**Current:** Results in 60 Days

**New:** 


---

## NOTES
- Images are handled separately and don't need text updates
- Video backgrounds are configured separately
- Some text may appear differently based on screen size
- Navigation menu items are universal across all pages
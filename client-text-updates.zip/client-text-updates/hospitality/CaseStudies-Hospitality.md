# Hospitality Case Studies Page - Text Updates
**Instructions:** Replace the "Current" text with your "New" text. Leave blank if no changes needed.

---

## PAGE HERO SECTION

### Hero Title
**Current:** Client Success Stories

**New:** 

### Hero Subtitle
**Current:** Real results from real businesses. See how Inteligencia transforms challenges into success stories.

**New:** 

### Hero Stats (4 metrics displayed at top)
#### Stat 1 - Value
**Current:** 4

**New:** 

#### Stat 1 - Label
**Current:** Industries

**New:** 

#### Stat 2 - Value
**Current:** 100+

**New:** 

#### Stat 2 - Label
**Current:** Success Stories

**New:** 

#### Stat 3 - Value
**Current:** $2.8M

**New:** 

#### Stat 3 - Label
**Current:** Revenue Generated

**New:** 

#### Stat 4 - Value
**Current:** 95%

**New:** 

#### Stat 4 - Label
**Current:** Client Retention

**New:** 

---

## CASE STUDY 1: 40 Acres Farmhouse

### Client Logo/Image
**Current:** /images/clients/40-acres-farmhouse-logo.png

**New:** 
(Upload logo/image file or provide URL)


### Client Name
**Current:** 40 Acres Farmhouse

**New:** 

### Challenge Section Title
**Current:** Challenge

**New:** 

### Challenge Description
**Current:** This luxury farmhouse retreat in South Africa was heavily dependent on OTAs, with commission fees eating into profitability. They needed to build direct booking channels while maintaining occupancy rates.

**New:** 

### Solution Section Title
**Current:** Solution

**New:** 

### Solution Description
**Current:** Implemented a comprehensive digital strategy including Google Hotel Ads, targeted social media campaigns for the local luxury travel market, and a sophisticated email nurture sequence for past guests. Built a "Book Direct" incentive program with exclusive perks.

**New:** 

### Results (3 metrics)
#### Result 1 - Value
**Current:** 40%

**New:** 

#### Result 1 - Label
**Current:** OTA Commission Savings

**New:** 

#### Result 2 - Value
**Current:** +65%

**New:** 

#### Result 2 - Label
**Current:** Direct Bookings

**New:** 

#### Result 3 - Value
**Current:** +45%

**New:** 

#### Result 3 - Label
**Current:** Repeat Guest Rate

**New:** 

### Timeline
**Current:** 6 months

**New:** 

### Testimonial Quote
**Current:** Laurie helped us build out our online channels, ramping up our initial demand, following this we were able to reduce OTA reliance and implement a Book Direct Strategy that saved us a ton in OTA Commissions. Laurie is great to work with, upbeat, efficient and most importantly, he gets results

**New:** 

### Testimonial Author
**Current:** Rodney Knotts

**New:** 

### Testimonial Position
**Current:** Owner

**New:** 

### Tags/Categories
**Current:** Boutique Hotels, Direct Bookings, OTA Optimization, South Africa

**New:** 

---

## CASE STUDY 2: Casa Salita and Suegra

### Client Logo/Image
**Current:** /images/clients/casa-salita-suegra-logo.png

**New:** 
(Upload logo/image file or provide URL)


### Client Name
**Current:** Casa Salita and Suegra

**New:** 

### Challenge Section Title
**Current:** Challenge

**New:** 

### Challenge Description
**Current:** This boutique property in Sayulita, Mexico had a real occupancy issue and needed a lifeline. Limited online presence and poor visibility across booking platforms were hurting revenue potential.

**New:** 

### Solution Section Title
**Current:** Solution

**New:** 

### Solution Description
**Current:** Built a new website, launched a combination of Google Hotel Ads and social media campaigns, and optimized their OTA channels. Created targeted campaigns for the Sayulita luxury vacation rental market.

**New:** 

### Results (3 metrics)
#### Result 1 - Value
**Current:** +53%

**New:** 

#### Result 1 - Label
**Current:** Occupancy Increase

**New:** 

#### Result 2 - Value
**Current:** +240%

**New:** 

#### Result 2 - Label
**Current:** Online Visibility

**New:** 

#### Result 3 - Value
**Current:** +180%

**New:** 

#### Result 3 - Label
**Current:** Booking Inquiries

**New:** 

### Timeline
**Current:** 6 months

**New:** 

### Testimonial Quote
**Current:** We had a real occupancy issue and needed a lifeline. Laurie built us a website, launched a combination of Hotel Ads and social media campaigns, and optimized our OTA channels. Our occupancy increased by 53% in just two months.

**New:** 

### Testimonial Author
**Current:** Jason Adelman

**New:** 

### Testimonial Position
**Current:** Owner

**New:** 

### Tags/Categories
**Current:** Vacation Rentals, Google Hotel Ads, Social Media, Mexico

**New:** 

---

## CASE STUDY 3: Hotel Amavi

### Client Logo/Image
**Current:** /images/clients/hotel-amavi-logo.png

**New:** 
(Upload logo/image file or provide URL)


### Client Name
**Current:** Hotel Amavi

**New:** 

### Challenge Section Title
**Current:** Challenge

**New:** 

### Challenge Description
**Current:** Hotel Amavi in Jaco, Costa Rica had never run Hotel Ads or Meta campaigns before and didn't know where to start. They needed efficient, targeted campaigns aligned with their goals.

**New:** 

### Solution Section Title
**Current:** Solution

**New:** 

### Solution Description
**Current:** Set up comprehensive Google Hotel Ads and Meta advertising campaigns seamlessly. Developed targeted strategies focused on the Costa Rica luxury hotel market with emphasis on direct bookings and cost efficiency.

**New:** 

### Results (3 metrics)
#### Result 1 - Value
**Current:** -50%

**New:** 

#### Result 1 - Label
**Current:** Cost-per-Booking

**New:** 

#### Result 2 - Value
**Current:** +85%

**New:** 

#### Result 2 - Label
**Current:** Direct Bookings

**New:** 

#### Result 3 - Value
**Current:** +120%

**New:** 

#### Result 3 - Label
**Current:** Campaign Efficiency

**New:** 

### Timeline
**Current:** 6 months

**New:** 

### Testimonial Quote
**Current:** We had never run Hotel Ads or Meta campaigns before, and honestly didn't know where to start. Laurie came in, set everything up seamlessly, and within weeks we saw a major spike in direct bookings. The Meta ads alone cut our cost-per-booking in half. His strategy just works — efficient, targeted, and totally aligned with our goals.

**New:** 

### Testimonial Author
**Current:** Stephanie Sitt

**New:** 

### Testimonial Position
**Current:** Owner

**New:** 

### Tags/Categories
**Current:** Boutique Hotels, Meta Advertising, Google Hotel Ads, Costa Rica

**New:** 

---

## BOTTOM CTA SECTION

### CTA Title
**Current:** Ready to Become Our Next Success Story?

**New:** 

### CTA Subtitle
**Current:** Join the businesses that have transformed their marketing and achieved remarkable results with Inteligencia.

**New:** 

### Primary CTA Button Text
**Current:** Get Your Free Analysis

**New:** 

### Secondary CTA Button Text
**Current:** View Our Services

**New:** 

---

## NOTES
- Timeline visualization is handled by code
- Company URLs/links are handled separately
- Location information may be displayed differently on mobile
- The timeline milestones are generated from the Solution text
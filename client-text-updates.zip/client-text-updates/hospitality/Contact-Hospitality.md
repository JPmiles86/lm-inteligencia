# Hospitality Contact Page - Text Updates
**Instructions:** Replace the "Current" text with your "New" text. Leave blank if no changes needed.

---

## PAGE HERO SECTION
*Note: Background uses a gradient effect (black → blue → black), not an image*

### Hero Title
**Current:** Ready to Transform Your Hotel's Performance?

**New:** 

### Hero Subtitle
**Current:** Get your free hotel marketing audit and discover how to reduce OTA dependency while increasing direct bookings.

**New:** 

---

## CONTACT FORM SECTION

### Form Title
**Current:** Send us a message

**New:** 

### Form Subtitle
**Current:** Fill out the form below and we'll get back to you within 24 hours with a customized strategy for your business.

**New:** 

### Form Fields Labels
#### First Name Label
**Current:** First Name *

**New:** 

#### Last Name Label
**Current:** Last Name *

**New:** 

#### Email Label
**Current:** Email Address *

**New:** 

#### Phone Label
**Current:** Phone Number

**New:** 

#### Business Name Label
**Current:** Business Name *

**New:** 

#### Business Type Label
**Current:** Business Type *

**New:** 

### Business Type Options (Dropdown)
#### Option 1
**Current:** Select your business type

**New:** 

#### Option 2
**Current:** Boutique Hotel

**New:** 

#### Option 3
**Current:** Resort

**New:** 

#### Option 4
**Current:** Bed & Breakfast

**New:** 

#### Option 5
**Current:** Vacation Rental

**New:** 

#### Option 6
**Current:** Hotel Chain

**New:** 

#### Option 7
**Current:** Other

**New:** 

### Marketing Budget Label
**Current:** Marketing Budget

**New:** 

### Budget Options (Dropdown)
#### Option 1
**Current:** Select your budget range

**New:** 

#### Option 2
**Current:** $1,000 - $2,500/month

**New:** 

#### Option 3
**Current:** $2,500 - $5,000/month

**New:** 

#### Option 4
**Current:** $5,000 - $10,000/month

**New:** 

#### Option 5
**Current:** $10,000+ /month

**New:** 

#### Option 6
**Current:** Let's discuss

**New:** 

### Timeline Label
**Current:** Timeline

**New:** 

### Timeline Helper Text
**Current:** When do you want to start?

**New:** 

### Timeline Options (Dropdown)
#### Option 1
**Current:** ASAP - I need help now

**New:** 

#### Option 2
**Current:** Within 1 month

**New:** 

#### Option 3
**Current:** 1-3 months

**New:** 

#### Option 4
**Current:** 3-6 months

**New:** 

#### Option 5
**Current:** Just exploring options

**New:** 

### Goals Field Label
**Current:** What are your main marketing goals? *

**New:** 

### Additional Details Label
**Current:** Additional Details

**New:** 

### Submit Button Text
**Current:** Send Message & Get Free Consultation

**New:** 

### Privacy Text
**Current:** We respect your privacy and will never share your information.

**New:** 

---

## GET IN TOUCH SECTION

### Section Title
**Current:** Get in Touch

**New:** 

### Section Subtitle
**Current:** Ready to discuss your hospitality marketing goals? Choose the contact method that works best for you.

**New:** 

### Email Contact
#### Label
**Current:** Email

**New:** 

#### Value
**Current:** hotels@inteligencia.com

**New:** 

#### Description
**Current:** Email us anytime - we respond within 24 hours

**New:** 

### Phone Contact
#### Label
**Current:** Phone

**New:** 

#### Value
**Current:** (555) 123-4567

**New:** 

#### Description
**Current:** Call us during business hours (9 AM - 6 PM EST)

**New:** 

### Office Contact
#### Label
**Current:** Office

**New:** 

#### Value
**Current:** 123 Business Ave, Suite 100, Miami, FL 33101

**New:** 

#### Description
**Current:** Visit our office for an in-person consultation

**New:** 

---

## SCHEDULE CONSULTATION SECTION

### Section Title
**Current:** Schedule Your Free Hotel Marketing Consultation

**New:** 

### Section Description
**Current:** Book a 30-minute strategy session to discuss your marketing goals and learn how we can help grow your business.

**New:** 

### Schedule Button Text
**Current:** Schedule Free Call

**New:** 

---

## OFFICE HOURS SECTION

### Section Title
**Current:** Office Hours

**New:** 

### Monday-Friday Hours
**Current:** Monday - Friday: 9:00 AM - 6:00 PM EST

**New:** 

### Saturday Hours
**Current:** Saturday: 10:00 AM - 2:00 PM EST

**New:** 

### Sunday Hours
**Current:** Sunday: Closed

**New:** 

### Emergency Support Text
**Current:** Emergency support available 24/7 for existing clients.

**New:** 

---

## FAQ SECTION

### Section Title
**Current:** Frequently Asked Questions

**New:** 

### Section Subtitle
**Current:** Common questions about working with our hospitality & lifestyle marketing team.

**New:** 

### FAQ 1
#### Question
**Current:** How quickly can I expect to see results?

**New:** 

#### Answer
**Current:** Most hotel clients see initial improvements within 30-60 days, with significant direct booking increases typically achieved within 3-6 months. The timeline depends on your current marketing foundation and campaign objectives.

**New:** 

### FAQ 2
#### Question
**Current:** Do you work with hotels outside of these industries?

**New:** 

#### Answer
**Current:** We focus exclusively on hospitality, food service, healthcare, and athletics to provide the deepest expertise possible. This specialization allows us to deliver superior results compared to generalist agencies.

**New:** 

### FAQ 3
#### Question
**Current:** What makes your approach different for hotels?

**New:** 

#### Answer
**Current:** Unlike generic marketing agencies, we understand the unique challenges of hotel marketing, including OTA dependency, seasonal demand, and direct booking optimization. Our strategies are built on hospitality-specific insights and proven best practices.

**New:** 

### FAQ 4
#### Question
**Current:** Do you require long-term contracts?

**New:** 

#### Answer
**Current:** We offer both monthly and annual plans. While we recommend longer commitments for best results, we understand every hotel has different needs and can work with you to find the right arrangement.

**New:** 

---

## NOTES
- Icons/emojis are handled separately in code
- Form validation is automatic
- Calendar/scheduling widget is integrated separately
- Some fields may be required or optional based on configuration
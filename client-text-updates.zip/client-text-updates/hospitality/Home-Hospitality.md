# Hospitality Home Page - Text Updates
**Instructions:** Replace the "Current" text with your "New" text. Leave blank if no changes needed.

---

## HERO SECTION

### Hero Background Video (Desktop)
**Current:** https://player.vimeo.com/video/1100417251

**New:** 
(Provide Vimeo or YouTube URL, or upload video file)


### Hero Background Video (Mobile)
**Current:** https://player.vimeo.com/video/1100417904

**New:** 
(Provide Vimeo or YouTube URL, or upload video file)


### Hero Title
**Current:** Digital Marketing That Drives Occupancy & Grows RevPAR

**New:** 


### Hero Subtitle  
**Current:** Drive direct bookings and reduce OTA dependency with AI-driven Marketing strategies

**New:** 


### Hero CTA Button Text
**Current:** Book Your Free Consultation

**New:** 


### Hero Stats (3 metrics displayed)
#### Stat 1 - Value
**Current:** 40%

**New:** 


#### Stat 1 - Label
**Current:** Increase in Direct Bookings

**New:** 


#### Stat 2 - Value
**Current:** 25%

**New:** 


#### Stat 2 - Label
**Current:** Reduction in OTA Commissions

**New:** 


#### Stat 3 - Value
**Current:** 60%

**New:** 


#### Stat 3 - Label
**Current:** Better ROI

**New:** 


---

## SERVICES SECTION

### Section Title
**Current:** Marketing That Moves The Metrics That Matter

**New:** 


### Section Subtitle
**Current:** AI-Driven Strategies for Hotels That Mean Business

**New:** 


---

## SERVICE 1: Hotels Ad Management

### Service Image
**Current:** /images/HotelAdsManagement.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Hotels Ad Management

**New:** 


### Key Benefit (displayed prominently)
**Current:** Reduce OTA dependency by 35%

**New:** 


### Service Description
**Current:** Drive direct bookings with targeted campaigns that reach travelers at the perfect moment.

**New:** 


---

## SERVICE 2: Meta (FB/IG) Advertising

### Service Image
**Current:** /images/MetaAdvertising.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Meta (FB/IG) Advertising

**New:** 


### Key Benefit (displayed prominently)
**Current:** Turn views into Bookings with Visual Impact

**New:** 


### Service Description
**Current:** Showcase your property with visual storytelling that inspires bookings and builds brand loyalty.

**New:** 


---

## SERVICE 3: Email Marketing & Funnels

### Service Image
**Current:** /images/EmailMarketing.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Email Marketing & Funnels

**New:** 


### Key Benefit (displayed prominently)
**Current:** 40% higher guest lifetime value

**New:** 


### Service Description
**Current:** Convert inquiries into bookings and guests into repeat customers with automated campaigns.

**New:** 


---

## SERVICE 4: Marketing Strategy Consulting

### Service Image
**Current:** /images/MarketingStrategy.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Marketing Strategy Consulting

**New:** 


### Key Benefit (displayed prominently)
**Current:** Increase RevPAR by 25%

**New:** 


### Service Description
**Current:** Get expert guidance to optimize your marketing mix and maximize revenue per available room.

**New:** 


---

## SERVICE 5: Event/Launch Campaigns

### Service Image
**Current:** /images/EventMarketing.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Event/Launch Campaigns

**New:** 


### Key Benefit (displayed prominently)
**Current:** Drive 85%+ Occupancy for Events

**New:** 


### Service Description
**Current:** Fill your property for special events, seasonal promotions, and grand openings with targeted campaigns.

**New:** 


---

## SERVICE 6: OTA Optimization & Demand Generation

### Service Image
**Current:** /images/OTAOptimization.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** OTA Optimization & Demand Generation

**New:** 


### Key Benefit (displayed prominently)
**Current:** Maximize visibility across all booking platforms

**New:** 


### Service Description
**Current:** Ensure every possible channel generates maximum demand particularly during low seasonal periods

**New:** 


---

## SERVICE 7: Restaurant Marketing

### Service Image
**Current:** /images/RestaurantMarketing.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Restaurant Marketing

**New:** 


### Key Benefit (displayed prominently)
**Current:** Increase Restaurant Bookings, Online Orders and ROI

**New:** 


### Service Description
**Current:** Fill Every Table Every Night: Drive Foot Traffic and Online orders with Restaurant Marketing that works

**New:** 


---

## TESTIMONIALS SECTION

### TESTIMONIAL 1: 40 Acres Farmhouse

#### Quote
**Current:** Laurie helped us build out our online channels, ramping up our initial demand, following this we were able to reduce OTA reliance and implement a Book Direct Strategy that saved us a ton in OTA Commissions. Laurie is great to work with, upbeat, efficient and most importantly, he gets results

**New:** 


#### Author Name
**Current:** Rodney Knotts

**New:** 


#### Author Position
**Current:** Owner

**New:** 


#### Company Name
**Current:** 40 Acres Farmhouse

**New:** 


#### Location
**Current:** Magaliesburg, South Africa

**New:** 


---

### TESTIMONIAL 2: Casa Salita and Suegra

#### Quote
**Current:** We had a real occupancy issue and needed a lifeline. Laurie built us a website, launched a combination of Hotel Ads and social media campaigns, and optimized our OTA channels. Our occupancy increased by 53% in just two months.

**New:** 


#### Author Name
**Current:** Jason Adelman

**New:** 


#### Author Position
**Current:** Owner

**New:** 


#### Company Name
**Current:** Casa Salita and Suegra

**New:** 


#### Location
**Current:** Sayulita, Mexico

**New:** 


---

### TESTIMONIAL 3: Hotel Amavi

#### Quote
**Current:** We had never run Hotel Ads or Meta campaigns before, and honestly didn't know where to start. Laurie came in, set everything up seamlessly, and within weeks we saw a major spike in direct bookings. The Meta ads alone cut our cost-per-booking in half. His strategy just works — efficient, targeted, and totally aligned with our goals.

**New:** 


#### Author Name
**Current:** Stephanie Sitt

**New:** 


#### Author Position
**Current:** Owner

**New:** 


#### Company Name
**Current:** Hotel Amavi

**New:** 


#### Location
**Current:** Jaco, Costa Rica

**New:** 


---

## VIDEO CTA SECTION (Bottom of page)

### Headline
**Current:** Ready to transform your hospitality business?

**New:** 


### Subtitle
**Current:** Let's discuss how AI-powered marketing can revolutionize your hotel's performance

**New:** 


### CTA Button Text
**Current:** Start Your Transformation

**New:** 


### Trust Indicators (3 lines displayed)
#### Line 1
**Current:** Free Strategy Consultation

**New:** 


#### Line 2
**Current:** No Long-term Contracts

**New:** 


#### Line 3
**Current:** Results in 30 Days

**New:** 


---

## NOTES
- Images are handled separately and don't need text updates
- Video backgrounds are configured separately
- Some text may appear differently based on screen size
- Navigation menu items are universal across all pages
# Hospitality Services Page - Text Updates (REVISED)
**Instructions:** This version references universal pricing. Only update industry-specific text.

---

## PAGE HERO SECTION

### Hero Title
**Current:** Where Hospitality Meets High-Performance Marketing

**New:** 


### Hero Subtitle
**Current:** Tailored Digital Growth Strategies for Premium Hotels & Resorts

**New:** 


---

## PRICING SECTION

### Section Title
**Current:** Simple, Transparent Pricing

**New:** 


---

## PRICING PLAN 1: Starter

***[Base Price & Universal Features: See Pricing-Universal-Structure.md]***

### Plan Name (Industry-Specific)
**Current:** Starter Hospitality

**New:** 


### Plan Description (Industry-Specific)
**Current:** Designed for boutique hotels or restaurants looking to boost visibility and drive bookings.

**New:** 


### Industry-Specific Features (Beyond universal features)
*Only list features unique to hospitality - universal features are in Pricing-Universal-Structure.md*

**Current:** None additional for hospitality

**New:** 


### Suitable For Text (Industry-Specific)
**Current:** Independent hotels, B&Bs, Restaurants, or new venues wanting to increase direct bookings or covers.

**New:** 


### CTA Button Text
**Current:** Get Started

**New:** 


---

## PRICING PLAN 2: Growth (RECOMMENDED)

***[Base Price & Universal Features: See Pricing-Universal-Structure.md]***

### Plan Name (Industry-Specific)
**Current:** Growth Hospitality

**New:** 


### Plan Description (Industry-Specific)
**Current:** For growing hotels and dining establishments ready to scale and optimize.

**New:** 


### Industry-Specific Features (Beyond universal features)
*Only list features unique to hospitality - universal features are in Pricing-Universal-Structure.md*

#### Industry Feature 1
**Current:** Funnel & Website Audit (Booking Journey or Menu/Reservation Flow)

**New:** 


#### Industry Feature 2
**Current:** Email List Review (Guest Nurture or Promo Campaigns)

**New:** 


### Suitable For Text (Industry-Specific)
**Current:** Hotels with 20–100 rooms, fine-dining restaurants, event-focused venues, or multi-location hospitality brands.

**New:** 


### CTA Button Text
**Current:** Get Started

**New:** 


---

## PRICING PLAN 3: Pro+

***[Base Price & Universal Features: See Pricing-Universal-Structure.md]***

### Plan Name (Industry-Specific)
**Current:** Pro+ Hospitality

**New:** 


### Plan Description (Industry-Specific)
**Current:** For luxury or multi-property brands seeking full-funnel revenue growth.

**New:** 


### Industry-Specific Features (Beyond universal features)
*Only list features unique to hospitality - universal features are in Pricing-Universal-Structure.md*

#### Industry Feature 1
**Current:** Full Funnel Build: from awareness to direct bookings

**New:** 


#### Industry Feature 2
**Current:** Creative Direction: Ad Copy + Visual Briefs tailored to your Property

**New:** 


#### Industry Feature 3
**Current:** Email Campaigns: Guest Nurture, Offers, Abandon Cart

**New:** 


### Suitable For Text (Industry-Specific)
**Current:** Luxury resorts, lifestyle hotel brands, restaurant groups, or hospitality groups with aggressive revenue targets.

**New:** 


### CTA Button Text
**Current:** Get Started

**New:** 


---

## OPTIONAL ADD-ONS SECTION

***[Pricing: See Pricing-Universal-Structure.md for add-on prices]***

### Custom Solution Text
**Current:** Need a custom solution? We'll create a package tailored to your specific needs and budget.

**New:** 


---

## SERVICES DETAILS SECTION

### Section Title
**Current:** What's Included in Every Package

**New:** 


### Section Subtitle
**Current:** Our comprehensive marketing services work together to drive growth and maximize your ROI.

**New:** 


---

## SERVICE DETAIL 1: Hotels Ad Management

### Service Image
**Current:** /images/HotelAdsManagement.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Hotels Ad Management

**New:** 


### Service Description
**Current:** Drive direct bookings with targeted campaigns that reach travelers at the perfect moment.

**New:** 


### Service Features (List format)
#### Feature 1
**Current:** Google Hotel Ads Setup

**New:** 


#### Feature 2
**Current:** Direct Booking Optimization

**New:** 


#### Feature 3
**Current:** Rate Parity Management

**New:** 


#### Feature 4
**Current:** Revenue Performance Tracking

**New:** 


---

## SERVICE DETAIL 2: Meta (FB/IG) Advertising

### Service Image
**Current:** /images/MetaAdvertising.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Meta (FB/IG) Advertising

**New:** 


### Service Description
**Current:** Reach leisure travelers on social media with stunning visuals and compelling offers.

**New:** 


### Service Features (List format)
#### Feature 1
**Current:** Facebook Ads Management

**New:** 


#### Feature 2
**Current:** Instagram Story Campaigns

**New:** 


#### Feature 3
**Current:** Lookalike Audience Building

**New:** 


#### Feature 4
**Current:** Dynamic Hotel Ads

**New:** 


---

## SERVICE DETAIL 3: Email Marketing & Funnels

### Service Image
**Current:** /images/EmailMarketing.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Email Marketing & Funnels

**New:** 


### Service Description
**Current:** Nurture guest relationships and drive repeat bookings with personalized campaigns.

**New:** 


### Service Features (List format)
#### Feature 1
**Current:** Guest Welcome Series

**New:** 


#### Feature 2
**Current:** Pre-Arrival Campaigns

**New:** 


#### Feature 3
**Current:** Loyalty Program Emails

**New:** 


#### Feature 4
**Current:** Seasonal Promotions

**New:** 


---

## SERVICE DETAIL 4: Marketing Strategy Consulting

### Service Image
**Current:** /images/MarketingStrategy.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Marketing Strategy Consulting

**New:** 


### Service Description
**Current:** Expert guidance on reducing OTA dependency and increasing direct revenue.

**New:** 


### Service Features (List format)
#### Feature 1
**Current:** Revenue Strategy Planning

**New:** 


#### Feature 2
**Current:** Channel Mix Optimization

**New:** 


#### Feature 3
**Current:** Competitive Analysis

**New:** 


#### Feature 4
**Current:** Direct Booking Roadmap

**New:** 


---

## SERVICE DETAIL 5: Event/Launch Campaigns

### Service Image
**Current:** /images/EventMarketing.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Event/Launch Campaigns

**New:** 


### Service Description
**Current:** Grand openings, renovations, or special events - we ensure maximum visibility.

**New:** 


### Service Features (List format)
#### Feature 1
**Current:** Pre-Launch Buzz Building

**New:** 


#### Feature 2
**Current:** Media & Influencer Outreach

**New:** 


#### Feature 3
**Current:** Opening Week Campaigns

**New:** 


#### Feature 4
**Current:** Post-Launch Momentum

**New:** 


---

## SERVICE DETAIL 6: OTA Optimization & Demand Generation

### Service Image
**Current:** /images/OTAOptimization.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** OTA Optimization & Demand Generation

**New:** 


### Service Description
**Current:** Maximize visibility on booking platforms while building direct booking channels.

**New:** 


### Service Features (List format)
#### Feature 1
**Current:** OTA Listing Optimization

**New:** 


#### Feature 2
**Current:** Review Management

**New:** 


#### Feature 3
**Current:** Ranking Improvement

**New:** 


#### Feature 4
**Current:** Channel Performance Analysis

**New:** 


---

## SERVICE DETAIL 7: Restaurant Marketing

### Service Image
**Current:** /images/RestaurantMarketing.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Restaurant Marketing

**New:** 


### Service Description
**Current:** Fill your hotel restaurant with both guests and locals through targeted campaigns.

**New:** 


### Service Features (List format)
#### Feature 1
**Current:** Local SEO Optimization

**New:** 


#### Feature 2
**Current:** Social Media Presence

**New:** 


#### Feature 3
**Current:** Event & Special Menus

**New:** 


#### Feature 4
**Current:** Guest Dining Campaigns

**New:** 


---

## BOTTOM CTA SECTION

### CTA Title
**Current:** Ready to Transform Your Hospitality & Lifestyle Marketing?

**New:** 


### CTA Subtitle
**Current:** Let's discuss how our proven strategies can help grow your business. Schedule a free consultation with our hospitality & lifestyle marketing experts today.

**New:** 


### CTA Button Text
**Current:** Get Your Free Consultation

**New:** 


---

## NOTES
- Universal pricing elements (prices, ad spend limits, etc.) are in Pricing-Universal-Structure.md
- Only update industry-specific descriptions and features here
- Emojis/icons are handled separately in the code
- Button links remain the same unless specified
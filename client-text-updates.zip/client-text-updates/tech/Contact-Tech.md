# Tech Contact Page - Text Updates
**Instructions:** Replace the "Current" text with your "New" text. Leave blank if no changes needed.

---

## PAGE HERO SECTION
*Note: Background uses a gradient effect (black → blue → black), not an image*

### Hero Title
**Current:** Ready to Scale Your Tech Company?

**New:** 

### Hero Subtitle
**Current:** Get your free growth audit and discover untapped opportunities to accelerate your business.

**New:** 

---

## CONTACT FORM SECTION

### Form Title
**Current:** Send us a message

**New:** 

### Form Subtitle
**Current:** Fill out the form below and we'll get back to you within 24 hours with a customized growth strategy.

**New:** 

### Form Fields Labels
#### First Name Label
**Current:** First Name *

**New:** 

#### Last Name Label
**Current:** Last Name *

**New:** 

#### Email Label
**Current:** Email Address *

**New:** 

#### Phone Label
**Current:** Phone Number

**New:** 

#### Business Name Label
**Current:** Company Name *

**New:** 

#### Business Type Label
**Current:** Business Type *

**New:** 

### Business Type Options (Dropdown)
#### Option 1
**Current:** Select your business type

**New:** 

#### Option 2
**Current:** SaaS

**New:** 

#### Option 3
**Current:** AI/ML Startup

**New:** 

#### Option 4
**Current:** Developer Tools

**New:** 

#### Option 5
**Current:** B2B Software

**New:** 

#### Option 6
**Current:** MarTech

**New:** 

#### Option 7
**Current:** FinTech

**New:** 

#### Option 8
**Current:** Other Tech

**New:** 

### Marketing Budget Label
**Current:** Marketing Budget

**New:** 

### Budget Options (Dropdown)
#### Option 1
**Current:** Select your budget range

**New:** 

#### Option 2
**Current:** $1,000 - $2,500/month

**New:** 

#### Option 3
**Current:** $2,500 - $5,000/month

**New:** 

#### Option 4
**Current:** $5,000 - $10,000/month

**New:** 

#### Option 5
**Current:** $10,000+ /month

**New:** 

#### Option 6
**Current:** Let's discuss

**New:** 

### Timeline Label
**Current:** Timeline

**New:** 

### Timeline Helper Text
**Current:** When do you want to start?

**New:** 

### Timeline Options (Dropdown)
#### Option 1
**Current:** ASAP - I need help now

**New:** 

#### Option 2
**Current:** Within 1 month

**New:** 

#### Option 3
**Current:** 1-3 months

**New:** 

#### Option 4
**Current:** 3-6 months

**New:** 

#### Option 5
**Current:** Just exploring options

**New:** 

### Goals Field Label
**Current:** What are your main growth goals? *

**New:** 

### Additional Details Label
**Current:** Additional Details

**New:** 

### Submit Button Text
**Current:** Send Message & Get Free Growth Audit

**New:** 

### Privacy Text
**Current:** We respect your privacy and will never share your information.

**New:** 

---

## GET IN TOUCH SECTION

### Section Title
**Current:** Get in Touch

**New:** 

### Section Subtitle
**Current:** Ready to discuss your tech company's growth? Choose the contact method that works best for you.

**New:** 

### Email Contact
#### Label
**Current:** Email

**New:** 

#### Value
**Current:** tech@inteligencia.com

**New:** 

#### Description
**Current:** Email us anytime - we respond within 24 hours

**New:** 

### Phone Contact
#### Label
**Current:** Phone

**New:** 

#### Value
**Current:** (555) 123-4567

**New:** 

#### Description
**Current:** Call us during business hours (9 AM - 6 PM EST)

**New:** 

### Office Contact
#### Label
**Current:** Office

**New:** 

#### Value
**Current:** 123 Business Ave, Suite 100, Miami, FL 33101

**New:** 

#### Description
**Current:** Visit our office for an in-person consultation

**New:** 

---

## SCHEDULE CONSULTATION SECTION

### Section Title
**Current:** Schedule Your Free Growth Strategy Session

**New:** 

### Section Description
**Current:** Book a 30-minute strategy session to discuss your growth goals and learn how we can help scale your business.

**New:** 

### Schedule Button Text
**Current:** Schedule Free Call

**New:** 

---

## OFFICE HOURS SECTION

### Section Title
**Current:** Office Hours

**New:** 

### Monday-Friday Hours
**Current:** Monday - Friday: 9:00 AM - 6:00 PM EST

**New:** 

### Saturday Hours
**Current:** Saturday: 10:00 AM - 2:00 PM EST

**New:** 

### Sunday Hours
**Current:** Sunday: Closed

**New:** 

### Emergency Support Text
**Current:** Emergency support available 24/7 for existing clients.

**New:** 

---

## FAQ SECTION

### Section Title
**Current:** Frequently Asked Questions

**New:** 

### Section Subtitle
**Current:** Common questions about working with our tech marketing team.

**New:** 

### FAQ 1
#### Question
**Current:** How quickly can I expect to see results?

**New:** 

#### Answer
**Current:** Most tech companies see initial improvements within 30-60 days, with significant growth metrics achieved within 3-6 months. We focus on both quick wins and sustainable long-term growth.

**New:** 

### FAQ 2
#### Question
**Current:** Do you work with companies outside of tech?

**New:** 

#### Answer
**Current:** We specialize in tech, hospitality, food service, healthcare, and athletics. Our tech vertical focuses exclusively on SaaS, AI/ML, and digital innovation companies.

**New:** 

### FAQ 3
#### Question
**Current:** What makes your approach different for tech companies?

**New:** 

#### Answer
**Current:** We understand SaaS metrics, product-led growth, developer marketing, and the unique challenges of scaling tech companies. Our strategies are data-driven and built on proven tech industry best practices.

**New:** 

### FAQ 4
#### Question
**Current:** Do you require long-term contracts?

**New:** 

#### Answer
**Current:** We offer flexible monthly plans with no long-term commitments required. However, we recommend at least 6 months to see meaningful growth and ROI.

**New:** 

---

## NOTES
- Icons/emojis are handled separately in code
- Form validation is automatic
- Calendar/scheduling widget is integrated separately
- Some fields may be required or optional based on configuration
# Tech Home Page - Text Updates
**Instructions:** Replace the "Current" text with your "New" text. Leave blank if no changes needed.

---

## HERO SECTION

### Hero Background Video (Desktop)
**Current:** https://player.vimeo.com/video/1100417251

**New:** 
(Provide Vimeo or YouTube URL, or upload video file)


### Hero Background Video (Mobile)
**Current:** https://player.vimeo.com/video/1100417904

**New:** 
(Provide Vimeo or YouTube URL, or upload video file)


### Hero Title
**Current:** Scale Your Tech Business with Data-Driven Marketing

**New:** 


### Hero Subtitle  
**Current:** Growth strategies for SaaS, AI startups, and digital innovators

**New:** 


### Hero CTA Button Text
**Current:** Book Your Growth Strategy Call

**New:** 


### Hero Stats (3 metrics displayed)
#### Stat 1 - Value
**Current:** 300%

**New:** 


#### Stat 1 - Label
**Current:** Average ARR Growth

**New:** 


#### Stat 2 - Value
**Current:** 50%

**New:** 


#### Stat 2 - Label
**Current:** Lower CAC

**New:** 


#### Stat 3 - Value
**Current:** 85%

**New:** 


#### Stat 3 - Label
**Current:** Better Product-Market Fit

**New:** 


---

## SERVICES SECTION

### Section Title
**Current:** Marketing Built for Tech Companies

**New:** 


### Section Subtitle
**Current:** Specialized strategies for SaaS, AI, and digital innovation

**New:** 


---

## SERVICE 1: SaaS Growth Marketing

### Service Image
**Current:** /images/SaaSGrowth.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** SaaS Growth Marketing

**New:** 


### Key Benefit (displayed prominently)
**Current:** Reduce CAC by 50% in 6 months

**New:** 


### Service Description
**Current:** Drive predictable revenue growth with funnel optimization and data-driven acquisition strategies.

**New:** 


---

## SERVICE 2: AI & ML Product Marketing

### Service Image
**Current:** /images/AIMarketing.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** AI & ML Product Marketing

**New:** 


### Key Benefit (displayed prominently)
**Current:** Achieve 85% product-market fit

**New:** 


### Service Description
**Current:** Position your AI solutions effectively and communicate complex value propositions clearly.

**New:** 


---

## SERVICE 3: B2B Demand Generation

### Service Image
**Current:** /images/B2BDemand.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** B2B Demand Generation

**New:** 


### Key Benefit (displayed prominently)
**Current:** 3x qualified lead generation

**New:** 


### Service Description
**Current:** Build sustainable pipelines with account-based marketing and enterprise sales enablement.

**New:** 


---

## SERVICE 4: Product Launch Campaigns

### Service Image
**Current:** /images/ProductLaunch.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Product Launch Campaigns

**New:** 


### Key Benefit (displayed prominently)
**Current:** 10,000+ launch week signups

**New:** 


### Service Description
**Current:** Execute flawless go-to-market strategies that capture market attention and drive adoption.

**New:** 


---

## SERVICE 5: Content & SEO Strategy

### Service Image
**Current:** /images/ContentSEO.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Content & SEO Strategy

**New:** 


### Key Benefit (displayed prominently)
**Current:** 500% organic traffic growth

**New:** 


### Service Description
**Current:** Build thought leadership and organic growth with technical content that ranks and converts.

**New:** 


---

## SERVICE 6: Paid Acquisition Mastery

### Service Image
**Current:** /images/PaidAcquisition.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Paid Acquisition Mastery

**New:** 


### Key Benefit (displayed prominently)
**Current:** 3.5x ROAS consistently

**New:** 


### Service Description
**Current:** Scale efficiently across Google, LinkedIn, and emerging platforms with advanced attribution.

**New:** 


---

## SERVICE 7: Analytics & Growth Ops

### Service Image
**Current:** /images/GrowthOps.png

**New:** 
(Upload image file or provide URL)


### Service Title
**Current:** Analytics & Growth Ops

**New:** 


### Key Benefit (displayed prominently)
**Current:** Real-time growth insights

**New:** 


### Service Description
**Current:** Build data infrastructure and growth processes that scale with your business.

**New:** 


---

## TESTIMONIALS SECTION

### TESTIMONIAL 1: CloudSync AI

#### Quote
**Current:** Laurie helped us reduce our customer acquisition cost by 60% while tripling our MRR. Their understanding of SaaS metrics and growth levers is exceptional.

**New:** 


#### Author Name
**Current:** David Chen

**New:** 


#### Author Position
**Current:** CEO

**New:** 


#### Company Name
**Current:** CloudSync AI

**New:** 


#### Location
**Current:** San Francisco, CA

**New:** 


---

### TESTIMONIAL 2: DataFlow Analytics

#### Quote
**Current:** Our product launch exceeded all expectations with 15,000 signups in the first week. Inteligencia's go-to-market strategy was flawless.

**New:** 


#### Author Name
**Current:** Sarah Johnson

**New:** 


#### Author Position
**Current:** VP Marketing

**New:** 


#### Company Name
**Current:** DataFlow Analytics

**New:** 


#### Location
**Current:** Austin, TX

**New:** 


---

### TESTIMONIAL 3: DevOps Pro

#### Quote
**Current:** They transformed our content strategy from generic blog posts to thought leadership that drives real pipeline. Our organic leads increased 400%.

**New:** 


#### Author Name
**Current:** Michael Torres

**New:** 


#### Author Position
**Current:** Founder

**New:** 


#### Company Name
**Current:** DevOps Pro

**New:** 


#### Location
**Current:** Seattle, WA

**New:** 


---

## VIDEO CTA SECTION (Bottom of page)

### Headline
**Current:** Ready to accelerate your tech company's growth?

**New:** 


### Subtitle
**Current:** Let's discuss how data-driven marketing can help you scale faster and more efficiently

**New:** 


### CTA Button Text
**Current:** Book Your Growth Strategy Call

**New:** 


### Trust Indicators (3 lines displayed)
#### Line 1
**Current:** Free Growth Audit

**New:** 


#### Line 2
**Current:** No Long-term Contracts

**New:** 


#### Line 3
**Current:** ROI in 90 Days

**New:** 


---

## NOTES
- Images are handled separately and don't need text updates
- Video backgrounds are configured separately
- Some text may appear differently based on screen size
- Navigation menu items are universal across all pages